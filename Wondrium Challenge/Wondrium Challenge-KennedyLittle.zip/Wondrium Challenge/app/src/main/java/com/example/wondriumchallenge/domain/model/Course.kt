package com.example.wondriumchallenge.domain.model


data class Course(
    val id: Int,
    val name: String,
    val imageName: String
)
