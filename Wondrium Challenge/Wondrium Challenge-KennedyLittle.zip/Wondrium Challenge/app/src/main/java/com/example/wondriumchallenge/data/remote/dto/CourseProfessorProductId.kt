package com.example.wondriumchallenge.data.remote.dto

import com.google.gson.annotations.SerializedName

data class CourseProfessorProductId(
    @SerializedName("professor_product_id")
    val professorProductId: Int
)