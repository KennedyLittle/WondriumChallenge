package com.example.wondriumchallenge.data.remote.dto

data class ResponseDto(
    val products: List<ProductDto>
)
