package com.example.wondriumchallenge.common

object Constants {

    const val BASE_URL = "https://rokudev.azurewebsites.net/"
    const val DETAILS_URL = "https://rokudev.azurewebsites.net/details"
}